# ALAN CLI TOOLSET

**********
This CLI toolset is built to serve my everyday need of news and information inside the CLI.In the future, I will also
support other format rather than just RSS.

How to use it (currently I haven't specified the setups , should be up pretty soon). First you install the
requirements.txt

## How to use the app
Type the below command for help
```shell
python main.py --help
```
Please remember to input the rss using rss manager in order for the manager to have data.

You can use above command to get the news after you have input the rss
```shell
python main.py get-news
```
![img.png](img.png)